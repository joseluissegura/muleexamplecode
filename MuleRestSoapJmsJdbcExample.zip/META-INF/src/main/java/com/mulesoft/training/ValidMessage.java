package com.mulesoft.training;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

public class ValidMessage  implements Callable  {
	private String requireMacros = "";
	public void setRequireMacros(String requireMacros)
	{
		this.requireMacros = requireMacros;
	}

	public boolean validateMessage (MuleMessage message) 
	{
		List<String> macrosNotPresent = new ArrayList<>();
		Map<String, Object> payload = (Map<String, Object>)message.getPayload();
		for (String key : requireMacros.split(","))
		{
			if (payload.get(key) == null)
			{
				macrosNotPresent.add(key);
			}
		}
		if (macrosNotPresent.size() > 0)
		{
			throw new RuntimeException("macros required:"+macrosNotPresent.toString());
		}
		return true; 
	}
	public Object onCall(MuleEventContext eventContext) throws Exception 
	{
		MuleMessage muleMessage = eventContext.getMessage();
		validateMessage(muleMessage);
		return muleMessage;
	}
}
