package com.mulesoft.training;

import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public interface SoapServerPriceComponent {
	String getPrice(@WebParam(name="destination") String destination);
}
