package com.mulesoft.training;

import javax.jws.WebService;

@WebService(
		endpointInterface="com.mulesoft.training.SoapServerPriceComponent"
		,
		serviceName="SoapServerPriceComponent"
)
public class SoapServerPriceComponentImpl extends PriceComponent implements SoapServerPriceComponent{

}
