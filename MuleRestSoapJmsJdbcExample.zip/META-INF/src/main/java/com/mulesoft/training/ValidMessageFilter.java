package com.mulesoft.training;

import java.util.Map;
import java.util.List;
import java.util.ArrayList;

import org.mule.api.MuleMessage;
import org.mule.api.routing.filter.Filter;

public class ValidMessageFilter implements Filter
{
	private String requireMacros = "";
	public void setRequireMacros(String requireMacros)
	{
		this.requireMacros = requireMacros;
	}
	
	public boolean accept (MuleMessage message) 
	{
		List<String> macrosNotPresent = new ArrayList<>();
		Map<String, Object> payload = (Map)message.getPayload();
		for (String key : requireMacros.split(","))
		{
			if (payload.get(key) == null)
			{
				macrosNotPresent.add(key);
			}
		}
		if (macrosNotPresent.size() > 0)
		{
			String errorMessage = "macros required:"+macrosNotPresent.toString();
			message.setPayload(errorMessage);
			message.setOutboundProperty("http.status", 500);
			//throw new RuntimeException(errorMessage);
			return false;
		}
		return true; 
	}
}
