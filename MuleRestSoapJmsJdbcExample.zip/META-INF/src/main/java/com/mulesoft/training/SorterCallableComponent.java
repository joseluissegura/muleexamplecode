package com.mulesoft.training;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.Collections;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

public class SorterCallableComponent implements Callable {
	private List<String> sortList(CopyOnWriteArrayList<String> myList){
		List<String> mylist2 = new ArrayList<>(myList);
		Collections.sort(mylist2);
		return mylist2;
	}
	
	public Object onCall(MuleEventContext eventContext) throws Exception{
		MuleMessage message=eventContext.getMessage(); 
		if (message.getPayload() instanceof CopyOnWriteArrayList){
			CopyOnWriteArrayList<String> payload=(CopyOnWriteArrayList<String>)message.getPayload();
			return sortList(payload);
		}
		return new CopyOnWriteArrayList<String>();
	}
	
}
