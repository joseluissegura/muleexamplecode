import static org.junit.Assert.*;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.mule.api.MuleException;
import org.mule.api.MuleMessage;
import org.mule.api.client.MuleClient;
import org.mule.tck.junit4.FunctionalTestCase;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class AllFlowTest extends FunctionalTestCase{
	@Test
	public void testAllFlowPOST() throws MuleException,Exception 
	{
		Map<String, Object> propsMap = new HashMap<>();
		propsMap.put("http.method", "POST");
		MuleClient client = muleContext.getClient();
		MuleMessage reply = client.send("vm://allFlow1", "SFO",propsMap, 5000);
		assertNotNull(reply);
		assertNotNull(reply.getPayload());
		assertTrue(reply.getPayload() instanceof Collection);
		CopyOnWriteArrayList<String> result = (CopyOnWriteArrayList<String>)reply.getPayload();
		assertTrue(result.size() == 4);
	}

	@Test
	public void testAllFlowGET() throws MuleException,Exception 
	{
		Map<String, Object> propsMap = new HashMap<>();
		propsMap.put("http.method", "GET");
		MuleClient client = muleContext.getClient();
		MuleMessage reply = client.send("vm://allFlow1", "SFO",propsMap, 5000);
		assertNotNull(reply);
		assertEquals(FileUtils.readFileToString(new File("src/main/resources/form.html")),reply.getPayloadAsString());
	}
	
	@Override
	protected String getConfigResources() 
	{
		return "src/main/app/mynewproject.xml";
	}

}
