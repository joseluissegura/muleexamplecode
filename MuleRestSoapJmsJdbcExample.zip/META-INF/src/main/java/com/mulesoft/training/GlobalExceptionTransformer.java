package com.mulesoft.training;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;


public class GlobalExceptionTransformer extends AbstractTransformer {
	private int propertyA;
	
	public void setPropertyA(int propertyA){
		this.propertyA = propertyA;
	}
	
	@Override
	protected Object doTransform(Object src, String encoding) throws TransformerException{
		return "0 Flee Exception "+propertyA;
	}
}