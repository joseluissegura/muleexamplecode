import static org.junit.Assert.*;
import org.junit.Test;
import org.mule.api.MuleException;
import org.mule.api.MuleMessage;
import org.mule.api.client.MuleClient;
import org.mule.tck.junit4.FunctionalTestCase;

public class UnitedFlowTest extends FunctionalTestCase{
	@Test
	public void testUnitFlow1() throws MuleException,Exception 
	{
		MuleClient client = muleContext.getClient();
		MuleMessage reply = client.send("vm://UnitedFlow", "SFO",null, 5000);
		assertNotNull(reply);
		assertNotNull(reply.getPayload());
		assertTrue(reply.getPayload() instanceof String);
		String result = reply.getPayloadAsString();
		assertTrue(result.equals("300 United"));
	}
	
	@Override
	protected String getConfigResources() 
	{
		return "src/main/app/mynewproject.xml";
	}
}
