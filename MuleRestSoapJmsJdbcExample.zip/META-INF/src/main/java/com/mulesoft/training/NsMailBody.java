package com.mulesoft.training;

import java.util.Map;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class NsMailBody extends AbstractTransformer {
	public String toString(Map<String,Object> keyValuePairs){
		StringBuffer sb = new StringBuffer();
		for (String key : keyValuePairs.keySet()){
			String value = (String)keyValuePairs.get(key);

			String keyValuePair;
            if (!key.equals("time")){
                keyValuePair = String.format("%s : [%s]\n\n",key,value);
            }
            else
            {
                keyValuePair = String.format("time : [%1$TD %1$TT]\n\n",Long.parseLong(value));
            }

			sb.append(keyValuePair);
		}
		return sb.toString();
	}

	@Override
	protected Object doTransform(Object src, String encoding) throws TransformerException{
		if (src instanceof Map){
			Map<String,Object> items = (Map<String,Object>)src;			
			return toString(items);
		}
		return "";
	}
}
