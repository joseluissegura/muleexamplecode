package com.mulesoft.training;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("/")
public class RestServerPriceComponent {
	@GET
	@Produces("text/plain")
	@Path("/getprice/destination/{destination}")
	public String getPrice(@PathParam("destination") String destination)
	{
		PriceComponent priceComponent = new PriceComponent();
		
		return priceComponent.getPrice(destination); 
	}
}
