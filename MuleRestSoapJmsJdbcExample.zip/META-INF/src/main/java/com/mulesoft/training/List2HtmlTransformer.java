package com.mulesoft.training;

import java.util.List;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class List2HtmlTransformer extends AbstractTransformer {
	public String toString(List<String> prices){
		StringBuffer sb = new StringBuffer();
		for (String price : prices){
			String priceWithTags = String.format("<p>%s<p>", price);
			sb.append(priceWithTags);
		}
		String html = String.format("<body><h1>Search Results</h1>%s</body>", sb.toString());
		return html;
	}
	
	@Override
	protected Object doTransform(Object src, String encoding) throws TransformerException{
		if (src instanceof List){
			List<String> prices = (List<String>)src;			
			return toString(prices);
		}
		return "<body></body>";
	}
}
